package com.byneet.doctor_consultant_mobile_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
