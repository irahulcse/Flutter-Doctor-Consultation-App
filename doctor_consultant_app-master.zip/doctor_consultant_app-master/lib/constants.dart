import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

const kBlack = Color(0xFF777A95);
const kGreen = Color(0xFF129A7F);
const kBlue = Color(0xFF5554DB);
const kOrange = Color(0xFFFFA873);
const kPurple = Color(0xFFA079EC);
const kGreyAccent = Color(0xFFF7F7F7);
const kGrey = Color(0xFFEEEEF0);

var kTitleStyle = GoogleFonts.poppins(
  color: kBlack,
  fontSize: 18.0,
  fontWeight: FontWeight.w600,
);

var kSubtitleStyle = GoogleFonts.poppins(
  color: kBlack,
  fontSize: 14.0,
);
